/** Passkeys for staff accounts: the same WebAuthn checks as the owner panel, stored per person. */
import type { Env } from '../env';
import { b64urlToBytes, checkCommon, derToRaw, importKey, type LoginInput, type RegisterInput } from '../panel/passkey';

export const MAX_PASSKEYS = 10;

export async function registerStaffPasskey(env: Env, userId: string, input: RegisterInput, origin: string, rpId: string): Promise<void> {
  if (!/^[A-Za-z0-9_-]{16,512}$/.test(input.id)) throw new Error('Bad credential id.');
  if (input.alg !== -7 && input.alg !== -257) throw new Error('Unsupported passkey type.');
  const n = await env.CATALOG_DB.prepare('SELECT count(*) AS n FROM staff_passkeys WHERE user_id = ?').bind(userId).first<{ n: number }>();
  if (Number(n?.n ?? 0) >= MAX_PASSKEYS) throw new Error('This account already has the most passkeys allowed. Remove one first.');
  const { signCount } = await checkCommon(env, 'register', input.clientDataJSON, input.authenticatorData, origin, rpId);
  await importKey(input.publicKey, input.alg); // proves the key parses
  await env.CATALOG_DB.prepare('INSERT INTO staff_passkeys (id, user_id, public_key, alg, sign_count, name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .bind(input.id, userId, input.publicKey, input.alg, signCount, (input.name ?? '').slice(0, 60) || 'Passkey', new Date().toISOString())
    .run();
}

/** Checks a sign-in assertion and returns the id of the person it belongs to. */
export async function verifyStaffPasskey(env: Env, input: LoginInput, origin: string, rpId: string): Promise<string> {
  const row = await env.CATALOG_DB.prepare('SELECT user_id, public_key, alg, sign_count FROM staff_passkeys WHERE id = ?')
    .bind(String(input.id ?? ''))
    .first<{ user_id: string; public_key: string; alg: number; sign_count: number }>();
  if (!row) throw new Error('This passkey is not registered here.');
  const { authData, signCount } = await checkCommon(env, 'login', input.clientDataJSON, input.authenticatorData, origin, rpId);
  const clientHash = new Uint8Array(await crypto.subtle.digest('SHA-256', b64urlToBytes(input.clientDataJSON)));
  const signed = new Uint8Array(new ArrayBuffer(authData.length + 32));
  signed.set(authData, 0);
  signed.set(clientHash, authData.length);
  const { key, params } = await importKey(row.public_key, row.alg);
  let sig = b64urlToBytes(input.signature);
  if (row.alg === -7) sig = derToRaw(sig);
  if (!(await crypto.subtle.verify(params, key, sig, signed))) throw new Error('The passkey signature did not verify.');
  // A counter that goes backwards suggests a cloned authenticator (synced passkeys report 0).
  if (signCount !== 0 && row.sign_count !== 0 && signCount <= row.sign_count) throw new Error('This passkey looks cloned. Ask an administrator to reset your sign-in.');
  await env.CATALOG_DB.prepare('UPDATE staff_passkeys SET sign_count = ?, last_used_at = ? WHERE id = ?').bind(signCount, new Date().toISOString(), input.id).run();
  return row.user_id;
}
