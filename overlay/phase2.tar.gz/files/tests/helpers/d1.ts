/** A small D1 stand-in over node:sqlite, enough for the staff and panel code under test. */
import { DatabaseSync } from 'node:sqlite';

type Args = Array<string | number | null>;

export function fakeD1(): D1Database & { raw: DatabaseSync } {
  const db = new DatabaseSync(':memory:');
  const statement = (sql: string, args: Args = []) => ({
    sql,
    args,
    bind: (...a: Args) => statement(sql, a),
    first: async () => (db.prepare(sql).get(...args) as unknown) ?? null,
    all: async () => ({ results: db.prepare(sql).all(...args) as unknown[], success: true, meta: {} }),
    run: async () => {
      const r = db.prepare(sql).run(...args);
      return { success: true, meta: { changes: Number(r.changes) } };
    },
  });
  const d1 = {
    raw: db,
    prepare: (sql: string) => statement(sql),
    batch: async (list: Array<ReturnType<typeof statement>>) => {
      db.exec('BEGIN');
      try {
        const out = list.map((s) => {
          const r = db.prepare(s.sql).run(...s.args);
          return { success: true, results: [], meta: { changes: Number(r.changes) } };
        });
        db.exec('COMMIT');
        return out;
      } catch (e) {
        db.exec('ROLLBACK');
        throw e;
      }
    },
  };
  return d1 as unknown as D1Database & { raw: DatabaseSync };
}
