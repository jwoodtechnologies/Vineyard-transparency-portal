import { describe, expect, it } from 'vitest';

function sse(chunks: string[]): ReadableStream<Uint8Array> {
  const enc = new TextEncoder();
  return new ReadableStream({
    start(c) {
      for (const x of chunks) c.enqueue(enc.encode(x));
      c.close();
    },
  });
}

describe('streamModel', () => {
  it('reassembles Workers AI server-sent events split at arbitrary byte boundaries', async () => {
    const { streamModel } = await import('../worker/ai/rag');
    const body = ['data: {"response":"The coun', 'cil approved"}\n\nda', 'ta: {"response":" it [1]."}\n\n', 'data: [DONE]\n\n'];
    const env = { AI: { run: async () => sse(body) } } as never;
    const seen: string[] = [];
    const raw = await streamModel(env, [{ role: 'user', content: 'q' }], async (t) => void seen.push(t));
    expect(raw).toBe('The council approved it [1].');
    expect(seen).toEqual(['The council approved', ' it [1].']);
  });

  it('accepts a non-streaming reply', async () => {
    const { streamModel } = await import('../worker/ai/rag');
    const env = { AI: { run: async () => ({ response: 'Done [1].' }) } } as never;
    const seen: string[] = [];
    expect(await streamModel(env, [], async (t) => void seen.push(t))).toBe('Done [1].');
    expect(seen).toEqual(['Done [1].']);
  });
});
