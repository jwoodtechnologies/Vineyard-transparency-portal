// Applies the Phase 2 bundle to the repository (run by .github/workflows/import-phase2.yml).
//   node apply.mjs <bundle files dir> <repo root>
// - copies new/replaced files
// - merges package.json scripts (keeps every existing script; the Phase 1 local ingest moves to ingest:local)
// - appends Phase 2 sections to existing docs (never deletes their content)
// - drops the premature HSTS header until the production domain is verified
import { cpSync, existsSync, readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';

const [, , files, root] = process.argv;
const here = dirname(new URL(import.meta.url).pathname);

cpSync(files, root, { recursive: true, force: true });

// package.json scripts
const pkgPath = join(root, 'package.json');
const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
const s = pkg.scripts;
if (s.ingest && s.ingest.startsWith('tsx')) s['ingest:local'] = s.ingest;
Object.assign(s, {
  'sources:discover': 'python3 -m ingest sources:discover',
  crawl: 'python3 -m ingest crawl',
  ingest: 'python3 -m ingest ingest',
  'ingest:resume': 'python3 -m ingest ingest:resume',
  'ingest:retry': 'python3 -m ingest retry-errors',
  index: 'python3 -m ingest index',
  verify: 'python3 -m ingest verify',
  stats: 'python3 -m ingest stats',
  'db:migrate': 'python3 -m ingest migrate',
  'test:ingest': "python3 -m unittest discover -s ingest/tests -p 'test_*.py'",
  'test:e2e': 'python3 -m ingest.tests.e2e_local',
});
writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');

// .gitignore
const gi = join(root, '.gitignore');
let g = readFileSync(gi, 'utf8');
for (const line of ['!.env.production', '__pycache__/', '*.pyc']) if (!g.split('\n').includes(line)) g += (g.endsWith('\n') ? '' : '\n') + line + '\n';
writeFileSync(gi, g);

// _headers: HSTS is enabled only after HTTPS on the production domain is verified (docs/CLOUDFLARE.md).
const hp = join(root, 'public/_headers');
if (existsSync(hp)) writeFileSync(hp, readFileSync(hp, 'utf8').split('\n').filter((l) => !/^\s*Strict-Transport-Security:/i.test(l)).join('\n'));

// Appended doc sections
const appendDir = join(here, 'append');
const walk = (d) => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : [join(d, f)]));
for (const f of existsSync(appendDir) ? walk(appendDir) : []) {
  const rel = f.slice(appendDir.length + 1);
  const target = join(root, rel);
  const add = readFileSync(f, 'utf8');
  const marker = add.split('\n')[0];
  const cur = existsSync(target) ? readFileSync(target, 'utf8') : '';
  if (!cur.includes(marker)) writeFileSync(target, cur + (cur.endsWith('\n') ? '\n' : '\n\n') + add);
}
console.log('Phase 2 bundle applied.');
