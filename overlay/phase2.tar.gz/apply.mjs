// Applies the Phase 2 bundle to the repository (run by .github/workflows/import-phase2.yml).
//   node apply.mjs <bundle files dir> <repo root>
// - copies new/replaced files
// - merges package.json scripts (keeps every existing script; the Phase 1 local ingest moves to ingest:local)
// - appends Phase 2 sections to existing docs (never deletes their content)
// - drops the premature HSTS header until the production domain is verified
import { cpSync, existsSync, readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';

const [, , files, root] = process.argv;
const here = dirname(new URL(import.meta.url).pathname);

cpSync(files, root, { recursive: true, force: true });

// package.json scripts
const pkgPath = join(root, 'package.json');
const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
const s = pkg.scripts;
if (s.ingest && s.ingest.startsWith('tsx')) s['ingest:local'] = s.ingest;
Object.assign(s, {
  'sources:discover': 'python3 -m ingest sources:discover',
  crawl: 'python3 -m ingest crawl',
  ingest: 'python3 -m ingest ingest',
  'ingest:resume': 'python3 -m ingest ingest:resume',
  'ingest:retry': 'python3 -m ingest retry-errors',
  index: 'python3 -m ingest index',
  verify: 'python3 -m ingest verify',
  stats: 'python3 -m ingest stats',
  'db:migrate': 'python3 -m ingest migrate',
  'test:ingest': "python3 -m unittest discover -s ingest/tests -p 'test_*.py'",
  'test:e2e': 'python3 -m ingest.tests.e2e_local',
});
writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');

// .gitignore
const gi = join(root, '.gitignore');
let g = readFileSync(gi, 'utf8');
for (const line of ['!.env.production', '__pycache__/', '*.pyc']) if (!g.split('\n').includes(line)) g += (g.endsWith('\n') ? '' : '\n') + line + '\n';
writeFileSync(gi, g);

// _headers: HSTS is enabled only after HTTPS on the production domain is verified (docs/CLOUDFLARE.md).
const hp = join(root, 'public/_headers');
if (existsSync(hp)) writeFileSync(hp, readFileSync(hp, 'utf8').split('\n').filter((l) => !/^\s*Strict-Transport-Security:/i.test(l)).join('\n'));

// Appended doc sections
const appendDir = join(here, 'append');
const walk = (d) => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : [join(d, f)]));
for (const f of existsSync(appendDir) ? walk(appendDir) : []) {
  const rel = f.slice(appendDir.length + 1);
  const target = join(root, rel);
  const add = readFileSync(f, 'utf8');
  const marker = add.split('\n')[0];
  const cur = existsSync(target) ? readFileSync(target, 'utf8') : '';
  if (!cur.includes(marker)) writeFileSync(target, cur + (cur.endsWith('\n') ? '\n' : '\n\n') + add);
}

// Speed: pdf.js loads only the byte ranges for the pages being viewed (the file endpoint serves
// HTTP ranges), instead of downloading a whole 20 MB agenda packet before showing page one.
const pdfViewer = join(root, 'src/components/documents/PdfViewer.tsx');
if (existsSync(pdfViewer)) {
  const t = readFileSync(pdfViewer, 'utf8');
  const n = t.replace('disableAutoFetch: false,', 'disableAutoFetch: true, disableStream: true, rangeChunkSize: 262144,');
  if (n !== t) writeFileSync(pdfViewer, n);
}

// Speed: the tiny theme script is render-blocking; let browsers keep it for a day instead of
// revalidating it on every visit.
if (existsSync(hp)) {
  const h = readFileSync(hp, 'utf8');
  if (!h.includes('/theme-init.js')) writeFileSync(hp, h.replace(/\s*$/, '\n') + '\n/theme-init.js\n  Cache-Control: public, max-age=86400, stale-while-revalidate=604800\n');
}
// Dictation: allow the microphone for this site only (it was blocked for every origin).
if (existsSync(hp)) {
  const h = readFileSync(hp, 'utf8');
  const n = h.replace('microphone=()', 'microphone=(self)');
  if (n !== h) writeFileSync(hp, n);
}


// Map page: MapLibre (open source) for the portal's own map of the city's GIS layers.
{
  const p = JSON.parse(readFileSync(pkgPath, 'utf8'));
  p.dependencies = p.dependencies ?? {};
  if (!p.dependencies['maplibre-gl']) {
    p.dependencies['maplibre-gl'] = '^6.11.2';
    p.dependencies = Object.fromEntries(Object.entries(p.dependencies).sort(([a], [b]) => a.localeCompare(b)));
    writeFileSync(pkgPath, JSON.stringify(p, null, 2) + '\n');
  }
}
// Map basemap tiles (OpenFreeMap, free, no key), same-origin PDF printing, and "show my location".
if (existsSync(hp)) {
  let h = readFileSync(hp, 'utf8');
  if (!h.includes('tiles.openfreemap.org')) h = h.replace("connect-src 'self'", "connect-src 'self' https://tiles.openfreemap.org");
  h = h.replace("frame-src 'none'", "frame-src 'self'").replace('geolocation=()', 'geolocation=(self)');
  writeFileSync(hp, h);
}
// Hourly check (Cron Trigger, free plan): meetings, newly posted records and Sheriff's Office news.
{
  const wp = join(root, 'wrangler.jsonc');
  const w = readFileSync(wp, 'utf8');
  if (!w.includes('"triggers"')) {
    const n = w.replace(/\n(\s*)"observability"/, '\n$1// Hourly check for new meetings, records and news (worker/cron.ts). Free plan.\n$1"triggers": { "crons": ["23 * * * *"] },\n$1"observability"');
    if (n === w) throw new Error('wrangler.jsonc: could not add the cron trigger');
    writeFileSync(wp, n);
  }
}

// Map styles: USGS imagery and topo (public domain) and AWS open elevation tiles for 3D terrain.
if (existsSync(hp)) {
  let h = readFileSync(hp, 'utf8');
  for (const host of ['https://basemap.nationalmap.gov', 'https://s3.amazonaws.com']) {
    if (!h.includes(host)) h = h.replace('https://tiles.openfreemap.org', `https://tiles.openfreemap.org ${host}`);
  }
  writeFileSync(hp, h);
}

console.log('Phase 2 bundle applied.');

// Latest page: Facebook's official Page Plugin shows the City and UCSO Vineyard posts.
if (existsSync(hp)) {
  const h = readFileSync(hp, 'utf8');
  if (!h.includes('https://www.facebook.com')) writeFileSync(hp, h.replace("frame-src 'self'", "frame-src 'self' https://www.facebook.com"));
}

// Use more of the D1 Free daily write allowance (100,000 rows) for the archive backfill, keeping
// about 10,000 rows of headroom for the hourly check and site activity.
{
  const wp = join(root, 'wrangler.jsonc');
  const w = readFileSync(wp, 'utf8');
  if (w.includes('"MAX_D1_INGEST_ROWS_PER_DAY": "75000"')) writeFileSync(wp, w.replace('"MAX_D1_INGEST_ROWS_PER_DAY": "75000"', '"MAX_D1_INGEST_ROWS_PER_DAY": "90000"'));
}

// Second search shard (vtp-search-1, D1 Free) so the full archive since 1989 has room. Both shards
// take new documents; searches read both and skip a shard that errors.
{
  const wp = join(root, 'wrangler.jsonc');
  let w = readFileSync(wp, 'utf8');
  if (!w.includes('"SEARCH_DB_1"')) {
    const n = w.replace(/(\{ "binding": "SEARCH_DB_0"[^\n]*\})/, '$1,\n    { "binding": "SEARCH_DB_1", "database_name": "vtp-search-1", "database_id": "b914c1ff-2d33-4973-a475-09dd4188bc75", "migrations_dir": "migrations/search" }');
    if (n === w) throw new Error('wrangler.jsonc: could not add SEARCH_DB_1');
    w = n;
  }
  w = w.replace('"SEARCH_SHARDS": "0",', '"SEARCH_SHARDS": "0,1",').replace('"SEARCH_WRITE_SHARDS": "0",', '"SEARCH_WRITE_SHARDS": "0,1",');
  writeFileSync(wp, w);
}

// Answers per day: the free Neuron allowance is the real limit (the larger model answers first,
// the small one after, and a spent allowance pauses AI answers until 00:00 UTC).
{
  const wp = join(root, 'wrangler.jsonc');
  const w = readFileSync(wp, 'utf8');
  if (w.includes('"AI_MAX_REQUESTS_PER_DAY": "120"')) writeFileSync(wp, w.replace('"AI_MAX_REQUESTS_PER_DAY": "120"', '"AI_MAX_REQUESTS_PER_DAY": "200"'));
}

// Workers Paid plan: D1 includes 50 million row writes a month and 10 GB per database, and Workers
// AI bills past the free 10,000 Neurons a day, so the backfill and answers are no longer capped.
{
  const wp = join(root, 'wrangler.jsonc');
  let w = readFileSync(wp, 'utf8');
  w = w.replace(/"MAX_D1_INGEST_ROWS_PER_DAY": "\d+"/, '"MAX_D1_INGEST_ROWS_PER_DAY": "3000000"').replace(/"AI_MAX_REQUESTS_PER_DAY": "\d+"/, '"AI_MAX_REQUESTS_PER_DAY": "3000"');
  if (!w.includes('"AI_BIG_PER_DAY"')) w = w.replace('"AI_MAX_REQUESTS_PER_DAY": "3000",', '"AI_MAX_REQUESTS_PER_DAY": "3000",\n    "AI_BIG_PER_DAY": "3000",');
  if (!w.includes('"SEARCH_SHARD_MAX_BYTES"')) w = w.replace('"AI_BIG_PER_DAY": "3000",', '"AI_BIG_PER_DAY": "3000",\n    "SEARCH_SHARD_MAX_BYTES": "9500000000",');
  else w = w.replace(/"SEARCH_SHARD_MAX_BYTES": "\d+"/, '"SEARCH_SHARD_MAX_BYTES": "9500000000"');
  writeFileSync(wp, w);
}

// AI stays inside the free 10,000 Neurons a day: a planned, reranked Qwen answer costs about 45 Neurons, so 220
// answers a day (plus search rewrites) never reach a charge. Past the cap answers fall back to search.
{
  const wp = join(root, 'wrangler.jsonc');
  const w = readFileSync(wp, 'utf8');
  writeFileSync(wp, w.replace(/"AI_MAX_REQUESTS_PER_DAY": "\d+"/, '"AI_MAX_REQUESTS_PER_DAY": "220"'));
}

// The agenda portal is checked every five minutes (worker/cron.ts); the full hourly check runs at the top of the hour.
{
  const wp = join(root, 'wrangler.jsonc');
  if (existsSync(wp)) {
    const t = readFileSync(wp, 'utf8');
    const next = t
      .replace(/"crons":\s*\["23 \* \* \* \*"\]/, '"crons": ["*/5 * * * *"]')
      .replace('// Hourly check for new meetings, records and news (worker/cron.ts). Free plan.', '// Every five minutes: new meetings and newly posted files (worker/cron.ts); news once an hour.');
    if (!next.includes('"crons": ["*/5 * * * *"]')) throw new Error('wrangler.jsonc cron trigger not patched');
    writeFileSync(wp, next);
  }
}
